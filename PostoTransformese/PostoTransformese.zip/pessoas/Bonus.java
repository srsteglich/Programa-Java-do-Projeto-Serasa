package pessoas;

public class Bonus {
	String nome;
	double valorDoTrabalho;
	
	public Bonus(String nomeRecebido, double valorDoTrabalhoRecebido) {
		nome = nomeRecebido;
		valorDoTrabalho = valorDoTrabalhoRecebido;
		
	}
	
}
