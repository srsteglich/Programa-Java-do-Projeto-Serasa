package pagamento;

public class pagamentoEmDebito {

	public static void pagoNoDebito(double quantiaEmDebito, double valorAbastecido) {
		
		if (quantiaEmDebito == valorAbastecido) {
			System.out.println("\n Obrigado, boa viagem!");
			
		
		}
	}
	
}
